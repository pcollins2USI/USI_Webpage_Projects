/*Car rental - This is where the program was left by one of your earlier exercises. You willl need to tweak it for Task 1 of pptx4.  */



function rental() {
	 document.getElementById('d_out').innerHTML =parseInt(days_out.value);	
	 document.getElementById('hr_out').innerHTML =parseInt(hrs_over.value);	 
	 document.getElementById('d_cost').innerHTML =(parseFloat(days_out.value)*75.3).toFixed(2);	 
	 document.getElementById('hr_cost').innerHTML =(parseFloat(hrs_over.value)*6.79).toFixed(2);
	 document.getElementById('tot_cost').innerHTML =((parseFloat(hrs_over.value)*6.79 + parseFloat(days_out.value)*75.3).toFixed(2));
}

//Tweak so arguments are passed to/received by a function
 